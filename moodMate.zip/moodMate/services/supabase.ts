import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import env from '../utils/env';

// Types for our database schema
export type Conversation = {
  id: string;
  user_id: string;
  title: string;
  created_at: string;
  updated_at: string;
};

export type Message = {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  created_at: string;
};

// Initialize Supabase client
const supabaseUrl = env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Database operations
export const db = {
  // Conversation operations
  conversations: {
    async create(userId: string, title: string = 'New Conversation'): Promise<Conversation> {
      const { data, error } = await supabase
        .from('conversations')
        .insert([
          {
            user_id: userId,
            title,
          },
        ])
        .select()
        .single();

      if (error) throw error;
      return data;
    },

    async getAll(userId: string): Promise<Conversation[]> {
      const { data, error } = await supabase
        .from('conversations')
        .select('*')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },

    async getById(id: string): Promise<Conversation> {
      const { data, error } = await supabase
        .from('conversations')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    },

    async update(id: string, updates: Partial<Conversation>): Promise<Conversation> {
      const { data, error } = await supabase
        .from('conversations')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },

    async delete(id: string): Promise<void> {
      const { error } = await supabase
        .from('conversations')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
  },

  // Message operations
  messages: {
    async create(conversationId: string, role: Message['role'], content: string): Promise<Message> {
      const { data, error } = await supabase
        .from('messages')
        .insert([
          {
            conversation_id: conversationId,
            role,
            content,
          },
        ])
        .select()
        .single();

      if (error) throw error;
      return data;
    },

    async getByConversationId(conversationId: string): Promise<Message[]> {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data || [];
    },

    async deleteByConversationId(conversationId: string): Promise<void> {
      const { error } = await supabase
        .from('messages')
        .delete()
        .eq('conversation_id', conversationId);

      if (error) throw error;
    },
  },
}; 