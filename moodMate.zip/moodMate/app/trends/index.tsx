import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Animated from 'react-native-reanimated';
import { FlatList } from 'react-native';

export default function Trends() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.menuButton}>
          <Ionicons name="menu" size={24} color="#2D3142" />
        </TouchableOpacity>
        <Text style={styles.title}>Trends</Text>
        <Text style={styles.subtitle}>Track your mood progress</Text>
      </View>
      
      <View style={styles.chartsContainer}>
        <View style={styles.chart}>
          <Text style={styles.chartTitle}>Weekly Mood</Text>
          <View style={styles.placeholderChart}>
            <Text style={styles.placeholderText}>
              Mood analytics chart will be displayed here
            </Text>
          </View>
        </View>
        
        <View style={styles.chart}>
          <Text style={styles.chartTitle}>Monthly Overview</Text>
          <View style={styles.placeholderChart}>
            <Text style={styles.placeholderText}>
              Monthly mood data will be displayed here
            </Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F3F3',
    padding: 16,
  },
  header: {
    marginTop: 20,
    marginBottom: 30,
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2D3142',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#4F5D75',
  },
  chartsContainer: {
    flex: 1,
    gap: 16,
  },
  chart: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: '500',
    color: '#2D3142',
    marginBottom: 12,
  },
  placeholderChart: {
    height: 150,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F3F3F3',
    borderRadius: 8,
  },
  placeholderText: {
    color: '#4F5D75',
    textAlign: 'center',
  },
  menuButton: {
    position: 'absolute',
    left: 16,
    top: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2D3142',
    marginBottom: 4,
  },
  headerButtons: {
    position: 'absolute',
    right: 16,
    top: 20,
  },
  sideMenu: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    backgroundColor: '#FFFFFF',
    padding: 16,
  },
});