import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  Button, 
  FlatList, 
  TouchableOpacity, 
  StyleSheet,
  ActivityIndicator,
  Platform
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { db, Conversation } from '../../services/supabase';
import { supabase } from '../../services/supabase';

type ChatStackParamList = {
  ChatHome: undefined;
  NewChat: undefined;
  ChatDetail: { conversationId: string };
  SupabaseTest: undefined;
};

type ChatScreenNavigationProp = StackNavigationProp<ChatStackParamList, 'ChatHome'>;

export default function ChatScreen() {
  const navigation = useNavigation<ChatScreenNavigationProp>();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserId(user.id);
        loadConversations(user.id);
      }
    };
    
    getCurrentUser();
  }, []);

  const loadConversations = async (uid: string) => {
    try {
      const userConversations = await db.conversations.getAll(uid);
      setConversations(userConversations);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNewChat = () => {
    navigation.navigate('NewChat');
  };

  const handleChatPress = (conversationId: string) => {
    navigation.navigate('ChatDetail', { conversationId });
  };

  const renderConversation = ({ item }: { item: Conversation }) => (
    <TouchableOpacity 
      style={styles.conversationItem}
      onPress={() => handleChatPress(item.id)}
    >
      <View style={styles.conversationContent}>
        <Text style={styles.conversationTitle}>{item.title}</Text>
        <Text style={styles.conversationDate}>
          {new Date(item.updated_at).toLocaleDateString()}
        </Text>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="blue" />
      </View>
    );
  }

  // If showing history mode
  if (showHistory) {
    return (
      <View style={styles.container}>
        <View style={styles.basicHeader}>
          <Text style={styles.headerText}>Chat History</Text>
          <Button 
            title="Close" 
            onPress={() => setShowHistory(false)} 
          />
        </View>

        <Button
          title="+ Start New Chat"
          onPress={handleNewChat}
        />

        <FlatList
          data={conversations}
          renderItem={renderConversation}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <Text style={styles.emptyText}>No conversations yet</Text>
          }
        />
      </View>
    );
  }

  // Normal chat screen
  return (
    <View style={styles.container}>
      <View style={styles.basicHeader}>
        <Button 
          title="Show History" 
          onPress={() => setShowHistory(true)} 
        />
        <Text style={styles.headerText}>AI Assistant</Text>
        <Button 
          title="New Chat" 
          onPress={handleNewChat} 
        />
      </View>

      <FlatList
        data={conversations}
        renderItem={renderConversation}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No conversations yet</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  basicHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  list: {
    padding: 10,
  },
  conversationItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  conversationContent: {
    flex: 1,
  },
  conversationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  conversationDate: {
    fontSize: 14,
    color: 'gray',
  },
  emptyText: {
    textAlign: 'center',
    padding: 20,
    color: 'gray',
  }
}); 