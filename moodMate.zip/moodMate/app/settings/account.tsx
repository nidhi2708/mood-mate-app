import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

export default function AccountSettings() {
  const navigation = useNavigation();
  const [isEditingName, setIsEditingName] = useState(false);
  const [isEditingSurname, setIsEditingSurname] = useState(false);
  const [isEditingAge, setIsEditingAge] = useState(false);
  const [name, setName] = useState("Daksh");
  const [surname, setSurname] = useState("Shukla");
  const [age, setAge] = useState("21");

  const handleDeleteAccount = () => {
    Alert.alert(
      "Delete Account",
      "Are you sure you want to delete your account? This action cannot be undone.",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            // In a real app, this would handle account deletion
            Alert.alert("Account Deleted", "Your account has been deleted.");
            navigation.goBack();
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="chevron-back" size={28} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Account Settings</Text>
        <View style={styles.placeholder} />
      </View>

      <View style={styles.content}>
        {/* Personal Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PERSONAL INFORMATION</Text>
          
          {/* Name Field */}
          <View style={styles.fieldContainer}>
            <Text style={styles.fieldLabel}>Name</Text>
            <View style={styles.fieldValue}>
              {isEditingName ? (
                <TextInput
                  style={styles.input}
                  value={name}
                  onChangeText={setName}
                  autoFocus
                  onBlur={() => setIsEditingName(false)}
                  onSubmitEditing={() => setIsEditingName(false)}
                />
              ) : (
                <>
                  <Text style={styles.fieldText}>{name}</Text>
                  <TouchableOpacity
                    style={styles.editButton}
                    onPress={() => setIsEditingName(true)}
                  >
                    <Ionicons name="pencil" size={18} color="#6B64F3" />
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
          
          {/* Surname Field */}
          <View style={styles.fieldContainer}>
            <Text style={styles.fieldLabel}>Surname</Text>
            <View style={styles.fieldValue}>
              {isEditingSurname ? (
                <TextInput
                  style={styles.input}
                  value={surname}
                  onChangeText={setSurname}
                  autoFocus
                  onBlur={() => setIsEditingSurname(false)}
                  onSubmitEditing={() => setIsEditingSurname(false)}
                />
              ) : (
                <>
                  <Text style={styles.fieldText}>{surname}</Text>
                  <TouchableOpacity
                    style={styles.editButton}
                    onPress={() => setIsEditingSurname(true)}
                  >
                    <Ionicons name="pencil" size={18} color="#6B64F3" />
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
          
          {/* Age Field */}
          <View style={styles.fieldContainer}>
            <Text style={styles.fieldLabel}>Age</Text>
            <View style={styles.fieldValue}>
              {isEditingAge ? (
                <TextInput
                  style={styles.input}
                  value={age}
                  onChangeText={setAge}
                  keyboardType="numeric"
                  autoFocus
                  onBlur={() => setIsEditingAge(false)}
                  onSubmitEditing={() => setIsEditingAge(false)}
                />
              ) : (
                <>
                  <Text style={styles.fieldText}>{age}</Text>
                  <TouchableOpacity
                    style={styles.editButton}
                    onPress={() => setIsEditingAge(true)}
                  >
                    <Ionicons name="pencil" size={18} color="#6B64F3" />
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
        </View>

        {/* Account Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ACCOUNT INFORMATION</Text>
          
          {/* Email Field - Non-editable */}
          <View style={styles.fieldContainer}>
            <Text style={styles.fieldLabel}>Email Address</Text>
            <View style={styles.nonEditableFieldValue}>
              <Text style={styles.nonEditableFieldText}>
                daksh1.mitmpl2022@learner.manipal.edu
              </Text>
            </View>
          </View>
        </View>

        {/* Danger Zone */}
        <View style={styles.dangerSection}>
          <Text style={styles.dangerSectionTitle}>DANGER ZONE</Text>
          
          <TouchableOpacity 
            style={styles.deleteButton}
            onPress={handleDeleteAccount}
          >
            <Text style={styles.deleteButtonText}>Delete My Account</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F5F5",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 10,
    backgroundColor: "#FFF",
    borderBottomWidth: 1,
    borderBottomColor: "#EEE",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#333",
  },
  placeholder: {
    width: 44,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  section: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "500",
    color: "#888",
    marginBottom: 16,
    letterSpacing: 1,
  },
  fieldContainer: {
    marginBottom: 16,
  },
  fieldLabel: {
    fontSize: 14,
    color: "#555",
    marginBottom: 8,
  },
  fieldValue: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#EEE",
    paddingBottom: 8,
  },
  fieldText: {
    fontSize: 16,
    color: "#333",
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#333",
    padding: 0,
  },
  editButton: {
    padding: 4,
  },
  nonEditableFieldValue: {
    backgroundColor: "#F0F0F0",
    borderRadius: 8,
    padding: 12,
  },
  nonEditableFieldText: {
    fontSize: 16,
    color: "#777",
  },
  dangerSection: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    padding: 16,
    marginTop: 10,
  },
  dangerSectionTitle: {
    fontSize: 13,
    fontWeight: "500",
    color: "#FF4E4E",
    marginBottom: 16,
    letterSpacing: 1,
  },
  deleteButton: {
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: "#FF4E4E",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
  },
  deleteButtonText: {
    fontSize: 16,
    fontWeight: "500",
    color: "#FF4E4E",
  },
});