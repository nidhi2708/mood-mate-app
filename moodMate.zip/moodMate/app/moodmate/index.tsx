import React, { useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Modal,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import claudeService from "../../services/claude";
import { useToast } from "../../utils/toast";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import type { StackNavigationProp } from "@react-navigation/stack";

// Add navigation type
type RootStackParamList = {
  ApiTest: undefined;
  ChatHome: undefined;
  MoodMate: { 
    sessionType?: string;
    initialMessage?: string;
  };
  // add other screens as needed
};

type NavigationProp = StackNavigationProp<RootStackParamList>;
type MoodMateScreenRouteProp = RouteProp<RootStackParamList, 'MoodMate'>;

type Message = {
  id: string;
  text: string;
  sender: "user" | "assistant";
  timestamp: Date;
};

export default function MoodMate() {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<MoodMateScreenRouteProp>();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSideMenu, setShowSideMenu] = useState(false);
  const scrollViewRef = React.useRef<ScrollView>(null);
  const { showToast } = useToast();

  // Set hardcoded API key on component mount
  useEffect(() => {
    claudeService.setApiKey("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");
  }, []);
  
  // Auto-send initial message based on session type
  useEffect(() => {
    if (route.params?.initialMessage) {
      // Small delay to make the UI render first
      const timer = setTimeout(() => {
        const initialMessage = route.params.initialMessage || "";
        setInputText(initialMessage);
        handleSend(initialMessage);
      }, 800);
      
      return () => clearTimeout(timer);
    }
  }, [route.params]);

  // Direct API test function
  const testClaudeAPI = async () => {
    setIsLoading(true);
    try {
      showToast("Testing API connection...", "info");
      console.log("Starting direct API test...");
      
      // Using the exact same parameters that worked in the curl command
      const apiKey = "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";
      const apiUrl = "https://api.anthropic.com/v1/messages";
      const model = "claude-3-5-haiku-20241022";
      
      // Create a simple message payload just like in the curl command
      const requestBody = {
        model: model,
        messages: [{ role: "user", content: "Hello" }],
        max_tokens: 100
      };
      
      try {
        // Try the real API call
        console.log("Attempting to connect to Claude API...");
        
        // Set a shorter timeout to fail faster if there are network issues
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
        
        const response = await fetch(apiUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            "anthropic-version": "2023-06-01"
          },
          body: JSON.stringify(requestBody),
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
          const responseText = await response.text();
          const data = JSON.parse(responseText);
          showToast("API connected successfully!", "success");
          
          // Display the real response
          const assistantMessage = data.content?.[0]?.text || "Hello from Claude!";
          const testMessage: Message = {
            id: Date.now().toString(),
            text: assistantMessage,
            sender: "assistant",
            timestamp: new Date(),
          };
          setMessages(prevMessages => [...prevMessages, testMessage]);
          return;
        }
      } catch (e) {
        console.log("API connection failed, using mock response instead");
        // Continue to fallback if the real API call fails
      }
      
      // If we get here, the API call failed - use mock response instead
      console.log("Using mock Claude response");
      showToast("Using offline mode with simulated responses", "info");
      
      // Simulate a short delay to make it feel realistic
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Add user test message
      const userMessage: Message = {
        id: Date.now().toString(),
        text: "Hello, Claude!",
        sender: "user",
        timestamp: new Date(),
      };
      setMessages(prevMessages => [...prevMessages, userMessage]);
      
      // Add mock Claude response
      setTimeout(() => {
        const mockClaudeMessage: Message = {
          id: Date.now().toString(),
          text: "Hi there! I'm using a simulated response because there seems to be a network issue connecting to the Claude API. This lets you test the app's interface without a working internet connection. How can I help you today?",
          sender: "assistant",
          timestamp: new Date(),
        };
        setMessages(prevMessages => [...prevMessages, mockClaudeMessage]);
      }, 1000);
      
    } catch (error) {
      console.error("Overall error in test function:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSend = async (messageText?: string) => {
    const textToSend = messageText || inputText;
    if (textToSend.trim() === "") return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: textToSend,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setInputText("");

    // Scroll to bottom
    scrollViewRef.current?.scrollToEnd({ animated: true });

    // Set loading state
    setIsLoading(true);

    try {
      // Get the appropriate prompt based on session type
      let promptPrefix = "";
      if (route.params?.sessionType === "morning") {
        promptPrefix = "The user wants to prepare for their day. Ask them about their priorities, plans, and any anticipated challenges. Help them start their day with a positive mindset. ";
      } else if (route.params?.sessionType === "evening") {
        promptPrefix = "The user wants to reflect on their day. Ask them about their accomplishments, challenges, and how they're feeling. Help them process their day and prepare for tomorrow. ";
      }
      
      // Call Claude API with the appropriate context
      const response = await claudeService.sendMessage(promptPrefix + textToSend);

      // Add Claude's response
      const assistantMessage: Message = {
        id: Date.now().toString(),
        text: response,
        sender: "assistant",
        timestamp: new Date(),
      };

      setMessages((prevMessages) => [...prevMessages, assistantMessage]);

      // Scroll to bottom
      scrollViewRef.current?.scrollToEnd({ animated: true });
    } catch (error) {
      // Handle errors
      console.error("Claude API call failed:", error);

      // Display the raw error message
      const rawErrorMessage = error instanceof Error ? error.message : String(error);
      showToast(`API Error: ${rawErrorMessage}`, "error");

      // Add a simple fallback error message in the chat
      const errorResponseMessage: Message = {
        id: Date.now().toString(),
        text: "Sorry, I couldn't connect. Please check the console logs.",
        sender: "assistant",
        timestamp: new Date(),
      };
      setMessages((prevMessages) => [...prevMessages, errorResponseMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.menuButton}>
          {/* Empty space on left for symmetry */}
        </View>
        <Text style={styles.title}>MoodMate</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity 
            style={styles.menuButton}
            onPress={testClaudeAPI}
          >
            <Ionicons name="bug-outline" size={24} color="#E74C3C" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.menuButton} 
            onPress={() => setShowSideMenu(true)}
          >
            <Ionicons name="menu" size={24} color="#2D3142" />
          </TouchableOpacity>
        </View>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.content}
        keyboardVerticalOffset={100}
      >
        <ScrollView
          style={styles.messageContainer}
          ref={scrollViewRef}
          contentContainerStyle={styles.messageContentContainer}
          onContentSizeChange={() =>
            scrollViewRef.current?.scrollToEnd({ animated: true })
          }
        >
          {messages.map((message) => (
            <View
              key={message.id}
              style={[
                styles.messageWrapper,
                message.sender === "user"
                  ? styles.userMessageWrapper
                  : styles.assistantMessageWrapper,
              ]}
            >
              <View
                style={[
                  styles.messageBubble,
                  message.sender === "user"
                    ? styles.userMessage
                    : styles.assistantMessage,
                ]}
              >
                <Text
                  style={[
                    styles.messageText,
                    message.sender === "user"
                      ? styles.userMessageText
                      : styles.assistantMessageText,
                  ]}
                >
                  {message.text}
                </Text>
              </View>
            </View>
          ))}

          {isLoading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="small" color="#6B64F3" />
              <Text style={styles.loadingText}>MoodMate is thinking...</Text>
            </View>
          )}
        </ScrollView>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Type a message..."
            placeholderTextColor="#999"
            value={inputText}
            onChangeText={setInputText}
            onSubmitEditing={() => handleSend()}
            returnKeyType="send"
            editable={!isLoading}
          />
          <TouchableOpacity
            style={styles.sendButton}
            onPress={() => handleSend()}
            disabled={inputText.trim() === "" || isLoading}
          >
            <Ionicons
              name="send"
              size={24}
              color={
                inputText.trim() === "" || isLoading ? "#CCCCCC" : "#6B64F3"
              }
            />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      {/* Side Menu Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={showSideMenu}
        onRequestClose={() => setShowSideMenu(false)}
      >
        <View style={styles.sideMenuContainer}>
          <View style={styles.sideMenuContent}>
            <View style={styles.sideMenuHeader}>
              <Text style={styles.sideMenuTitle}>Conversation History</Text>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setShowSideMenu(false)}
              >
                <Ionicons name="close" size={24} color="#2D3142" />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.conversationList}>
              {messages.length > 0 ? (
                messages
                  .filter(msg => msg.sender === "user")
                  .map((msg) => (
                    <View key={msg.id} style={styles.conversationItem}>
                      <Text style={styles.conversationText} numberOfLines={1}>
                        {msg.text}
                      </Text>
                      <Text style={styles.conversationTime}>
                        {msg.timestamp.toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </Text>
                    </View>
                  ))
              ) : (
                <View style={styles.emptyConversation}>
                  <Text style={styles.emptyConversationText}>
                    No conversations yet
                  </Text>
                </View>
              )}
            </ScrollView>
          </View>
          <TouchableOpacity
            style={styles.overlay}
            activeOpacity={0.5}
            onPress={() => setShowSideMenu(false)}
          />
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F8FC",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#EFEFEF",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#2D3142",
  },
  menuButton: {
    padding: 8,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
  },
  content: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
  },
  messageContainer: {
    flex: 1,
    padding: 16,
  },
  messageContentContainer: {
    paddingBottom: 16,
  },
  messageWrapper: {
    width: "100%",
    marginBottom: 12,
  },
  userMessageWrapper: {
    alignItems: "flex-end",
  },
  assistantMessageWrapper: {
    alignItems: "flex-start",
  },
  messageBubble: {
    padding: 12,
    borderRadius: 16,
    maxWidth: "80%",
  },
  userMessage: {
    backgroundColor: "#6B64F3",
    borderTopRightRadius: 4,
  },
  assistantMessage: {
    backgroundColor: "#F0E5FF",
    borderTopLeftRadius: 4,
  },
  messageText: {
    fontSize: 16,
  },
  userMessageText: {
    color: "#FFFFFF",
  },
  assistantMessageText: {
    color: "#2D3142",
  },
  loadingContainer: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    marginVertical: 10,
    backgroundColor: "#F0E5FF",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
  },
  loadingText: {
    marginLeft: 8,
    color: "#6B64F3",
    fontSize: 14,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 25,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "#EFEFEF",
    margin: 16,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#2D3142",
    paddingVertical: 8,
  },
  sendButton: {
    padding: 8,
  },
  sideMenuContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  sideMenuContent: {
    width: '80%',
    height: '100%',
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  sideMenuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
    marginTop: 40,
  },
  sideMenuTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2D3142',
  },
  closeButton: {
    padding: 8,
  },
  conversationList: {
    flex: 1,
  },
  conversationItem: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
  },
  conversationText: {
    fontSize: 16,
    color: '#2D3142',
    marginBottom: 4,
  },
  conversationTime: {
    fontSize: 12,
    color: '#999',
  },
  emptyConversation: {
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyConversationText: {
    fontSize: 16,
    color: '#999',
  },
});
