import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import SupabaseTest from '../utils/supabase-test';

export default function SupabaseTestScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <SupabaseTest />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F8FC',
  },
}); 