import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

// Define the navigation param list
type RootStackParamList = {
  Explore: undefined;
  // Add other screens as needed
};

type NavigationProp = StackNavigationProp<RootStackParamList>;

export default function InspirationSection() {
  const navigation = useNavigation<NavigationProp>();
  
  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>GET INSPIRED</Text>
      
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.cardsContainer}
        pagingEnabled
        decelerationRate="fast"
        snapToInterval={280} // Width of card + margin
        snapToAlignment="center"
      >
        {/* Intro Card */}
        <View style={styles.card}>
          <View style={styles.cardContent}>
            <Text style={styles.introCardTitle}>
              Looking for more{'\n'}Inspiration?
            </Text>
            <TouchableOpacity 
              style={styles.getInspiredButton}
              onPress={() => navigation.navigate('Explore')}
            >
              <Text style={styles.getInspiredButtonText}>Get Inspired</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Quote Card */}
        <View style={styles.card}>
          <View style={styles.cardContent}>
            <View style={styles.quoteIconContainer}>
              <Text style={styles.quoteIcon}>❞</Text>
            </View>
            <Text style={styles.quoteText}>
              The antidote for fifty enemies is one friend.
            </Text>
            <Text style={styles.quoteAuthor}>Aristotle</Text>
            <TouchableOpacity style={styles.reflectButton}>
              <Text style={styles.reflectButtonText}>Reflect</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Daily Affirmation Card */}
        <View style={styles.card}>
          <View style={styles.cardContent}>
            <View style={styles.affirmationIconContainer}>
              <Ionicons name="sunny" size={40} color="#000" />
            </View>
            <Text style={styles.affirmationLabel}>Daily Affirmation</Text>
            <Text style={styles.affirmationText}>
              I believe that my time is valuable.
            </Text>
            <TouchableOpacity style={styles.reflectButton}>
              <Text style={styles.reflectButtonText}>Reflect</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Question Prompt Card */}
        <View style={styles.card}>
          <View style={styles.cardContent}>
            <View style={styles.questionIconContainer}>
              <Ionicons name="bulb" size={40} color="#000" />
            </View>
            <Text style={styles.questionText}>
              Do you think you might be a source of gratitude for someone else?
            </Text>
            <TouchableOpacity style={styles.reflectButton}>
              <Text style={styles.reflectButtonText}>Reflect</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 14,
    color: '#999',
    letterSpacing: 1.5,
    marginBottom: 16,
    textAlign: 'center',
  },
  cardsContainer: {
    paddingRight: 16,
  },
  card: {
    width: 280,
    height: 380,
    backgroundColor: '#FFF',
    borderRadius: 25,
    marginRight: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    justifyContent: 'center',
  },
  cardContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  introCardTitle: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1E1E1E',
    textAlign: 'center',
    marginBottom: 40,
  },
  getInspiredButton: {
    backgroundColor: '#1E1E1E',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 30,
  },
  getInspiredButtonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '600',
  },
  quoteIconContainer: {
    marginBottom: 20,
  },
  quoteIcon: {
    fontSize: 80,
    color: '#1E1E1E',
    lineHeight: 80,
  },
  quoteText: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1E1E1E',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 36,
  },
  quoteAuthor: {
    fontSize: 20,
    color: '#999',
    textAlign: 'center',
    marginBottom: 40,
  },
  reflectButton: {
    borderColor: '#1E1E1E',
    borderWidth: 1,
    paddingHorizontal: 40,
    paddingVertical: 12,
    borderRadius: 30,
  },
  reflectButtonText: {
    color: '#1E1E1E',
    fontSize: 18,
    fontWeight: '500',
  },
  affirmationIconContainer: {
    marginBottom: 10,
  },
  affirmationLabel: {
    fontSize: 18,
    color: '#999',
    marginBottom: 20,
  },
  affirmationText: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1E1E1E',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 38,
  },
  questionIconContainer: {
    marginBottom: 20,
  },
  questionText: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1E1E1E',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 38,
  },
}); 