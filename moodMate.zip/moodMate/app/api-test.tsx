import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';

// API Constants
const API_KEY = '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';
const API_URL = 'https://api.anthropic.com/v1/messages';
const API_MODEL = 'claude-3-opus-20240229';

export default function ApiTestScreen() {
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const runApiTest = async () => {
    setIsLoading(true);
    setError(null);
    setTestResult(null);
    
    try {
      console.log('Testing Claude API connection...');
      
      // Simple test message
      const testMessage = 'Hello, this is a test message to verify the API connection.';
      
      // Prepare request body according to Claude API spec
      const requestBody = {
        model: API_MODEL,
        messages: [
          { role: 'user', content: testMessage }
        ],
        max_tokens: 100,
      };

      console.log('Making test API request to:', API_URL);
      console.log('Using API key:', `${API_KEY.substring(0, 8)}...${API_KEY.substring(API_KEY.length - 4)}`);
      
      // Make API request
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_KEY}`,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify(requestBody),
      });

      const responseText = await response.text();
      console.log('API Response status:', response.status);
      console.log('Raw response:', responseText);
      
      if (!response.ok) {
        let errorMessage = 'Unknown error';
        try {
          const errorData = JSON.parse(responseText);
          errorMessage = errorData.error?.message || 'Unknown API error';
          setError(`API Error (${response.status}): ${errorMessage}`);
        } catch (e) {
          setError(`API Error (${response.status}): ${responseText}`);
        }
      } else {
        try {
          const data = JSON.parse(responseText);
          setTestResult(JSON.stringify(data, null, 2));
        } catch (e) {
          setError('Failed to parse API response');
        }
      }
    } catch (error) {
      console.error('API test error:', error);
      setError(`Connection error: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ title: 'Claude API Test' }} />
      
      <View style={styles.content}>
        <Text style={styles.title}>Claude API Test</Text>
        
        <TouchableOpacity 
          style={styles.testButton} 
          onPress={runApiTest}
          disabled={isLoading}
        >
          <Text style={styles.buttonText}>
            {isLoading ? 'Testing...' : 'Test API Connection'}
          </Text>
          {isLoading && <ActivityIndicator color="#fff" style={styles.loader} />}
        </TouchableOpacity>
        
        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorTitle}>Error:</Text>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}
        
        {testResult && (
          <View style={styles.resultContainer}>
            <Text style={styles.resultTitle}>Success! API Response:</Text>
            <ScrollView style={styles.responseScroll}>
              <Text style={styles.responseText}>{testResult}</Text>
            </ScrollView>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F8FC',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2D3142',
    marginBottom: 24,
    textAlign: 'center',
  },
  testButton: {
    backgroundColor: '#6B64F3',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  loader: {
    marginLeft: 8,
  },
  errorContainer: {
    backgroundColor: '#FFECEC',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  errorTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#E74C3C',
    marginBottom: 8,
  },
  errorText: {
    color: '#E74C3C',
    fontSize: 14,
  },
  resultContainer: {
    flex: 1,
    backgroundColor: '#EEFDF5',
    padding: 16,
    borderRadius: 8,
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2ECC71',
    marginBottom: 8,
  },
  responseScroll: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 8,
  },
  responseText: {
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    fontSize: 12,
  },
}); 