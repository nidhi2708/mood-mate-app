import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import {
  Provider as PaperProvider,
  MD3LightTheme,
  adaptNavigationTheme,
} from "react-native-paper";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

// Screen components
import Home from "./index";
import Chat from "./chat";
import NewChat from "./chat/new-chat";
import ChatDetail from "./chat/chat-detail";
import Trends from "./trends";
import Settings from "./settings";
import AccountSettings from "./settings/account";
import SupabaseTestScreen from "./supabase-test";
import ChatHistoryScreen from './chat/history';
import ApiTestScreen from './api-test';

// Theme configuration
const theme = {
  ...MD3LightTheme,
  colors: {
    ...MD3LightTheme.colors,
    primary: "#2D3142",
    secondary: "#4F5D75",
    background: "#F3F3F3",
    surface: "#FFFFFF",
  },
};

// Set up navigation types
const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// Stack Navigator for Settings
function SettingsStack() {
  return (
    <Stack.Navigator
      initialRouteName="Settings"
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name="Settings" component={Settings} />
      <Stack.Screen name="AccountSettings" component={AccountSettings} />
    </Stack.Navigator>
  );
}

// Home Stack to allow navigation to settings
function HomeStack() {
  return (
    <Stack.Navigator
      initialRouteName="HomeScreen"
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name="HomeScreen" component={Home} />
      <Stack.Screen name="SettingsStack" component={SettingsStack} />
    </Stack.Navigator>
  );
}

// Stack Navigator for Chat
function ChatStack() {
  return (
    <Stack.Navigator
      initialRouteName="ChatHome"
      screenOptions={{
        headerShown: false,
        presentation: 'modal',  // This makes it slide up from bottom
      }}
    >
      <Stack.Screen name="ChatHome" component={Chat} />
      <Stack.Screen name="NewChat" component={NewChat} />
      <Stack.Screen name="ChatDetail" component={ChatDetail} />
      <Stack.Screen name="SupabaseTest" component={SupabaseTestScreen} />
      <Stack.Screen name="ChatHistory" component={ChatHistoryScreen} />
      <Stack.Screen name="ApiTest" component={ApiTestScreen} />
    </Stack.Navigator>
  );
}

export default function Layout() {
  return (
    <SafeAreaProvider>
      <PaperProvider theme={theme}>
        <NavigationContainer>
          <Tab.Navigator
            screenOptions={({ route }) => ({
              headerShown: false,
              tabBarIcon: ({ focused, color, size }) => {
                let iconName;

                if (route.name === "Home") {
                  iconName = focused ? "home" : "home-outline";
                } else if (route.name === "AI Assistant") {
                  iconName = focused ? "chatbubble" : "chatbubble-outline";
                } else if (route.name === "Trends") {
                  iconName = focused ? "analytics" : "analytics-outline";
                }

                // Ensure iconName is always a valid string
                return (
                  <Ionicons name={iconName as any} size={size} color={color} />
                );
              },
              tabBarActiveTintColor: theme.colors.primary,
              tabBarInactiveTintColor: "gray",
              tabBarStyle: {
                paddingBottom: 5,
                height: 60,
              },
            })}
          >
            <Tab.Screen name="Home" component={HomeStack} />
            <Tab.Screen name="AI Assistant" component={ChatStack} />
            <Tab.Screen name="Trends" component={Trends} />
          </Tab.Navigator>
        </NavigationContainer>
      </PaperProvider>
    </SafeAreaProvider>
  );
}
