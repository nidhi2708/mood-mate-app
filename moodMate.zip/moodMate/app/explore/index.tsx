import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  Modal,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

// SVG components for the category cards
const FeatherIcon = () => (
  <View style={styles.svgContainer}>
    <Text style={styles.svgIcon}>🪶</Text>
  </View>
);

const FlowerIcon = () => (
  <View style={styles.svgContainer}>
    <Text style={styles.svgIcon}>❄️</Text>
  </View>
);

const MeditationIcon = () => (
  <View style={styles.svgContainer}>
    <Text style={styles.svgIcon}>⚪</Text>
  </View>
);

const LightbulbIcon = () => (
  <View style={styles.svgContainer}>
    <Text style={styles.svgIcon}>💡</Text>
  </View>
);

const SunIcon = () => (
  <View style={styles.svgContainer}>
    <Text style={styles.svgIcon}>☀️</Text>
  </View>
);

const LeafIcon = () => (
  <View style={styles.svgContainer}>
    <Text style={styles.svgIcon}>🍃</Text>
  </View>
);

const MoonIcon = () => (
  <View style={styles.svgContainer}>
    <Text style={styles.svgIcon}>🌙</Text>
  </View>
);

export default function Explore() {
  const [filtersModalVisible, setFiltersModalVisible] = useState(false);
  const [selectedFilters, setSelectedFilters] = useState({
    morningQuestions: false,
    eveningQuestions: false,
    photos: false,
    journal: false,
    breathing: false,
    meditation: false,
    moodCheckIn: false,
    quote: false,
    affirmation: false,
    readingSession: false,
    walks: false
  });

  // Toggle filter selection
  const toggleFilter = (filter: keyof typeof selectedFilters) => {
    setSelectedFilters(prev => ({
      ...prev,
      [filter]: !prev[filter]
    }));
  };

  // Category filters
  const categories = [
    { id: 1, name: "Morning" },
    { id: 2, name: "During the Day" },
    { id: 3, name: "Sleep" },
    { id: 4, name: "General" },
    { id: 5, name: "Productivity" },
  ];

  // Recommended activities based on user's day
  const recommendedActivities = [
    {
      id: 1,
      title: "Unguided",
      subtitle: "Meditation",
      icon: <SunIcon />,
    },
    {
      id: 2,
      title: "Empty Page",
      subtitle: "Journaling",
      icon: <LeafIcon />,
    },
    {
      id: 3,
      title: "Sleep",
      subtitle: "Breathing",
      icon: <MoonIcon />,
    },
  ];

  // Featured content
  const featuredContent = [
    {
      id: 1,
      title: "Life's better without stressing about it!",
      description:
        "April is World Stress Awareness Month! What better time to give yourself a break...",
      dateRange: "6 Apr - 1 May",
      actionText: "Manage stress",
      icon: <LightbulbIcon />,
    },
    {
      id: 2,
      title: "On Odes",
      label: "New",
      icon: <FeatherIcon />,
    },
    {
      id: 3,
      title: "Mood Check-In",
      label: "Featured",
      icon: <FlowerIcon />,
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      {/* Header with Menu Button */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.menuButton} onPress={() => setFiltersModalVisible(true)}>
          <Ionicons name="menu" size={24} color="#2D3142" />
        </TouchableOpacity>
        <View style={{ flex: 1 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <Ionicons name="search" size={20} color="#888" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Exercises, quotes and your entries..."
            placeholderTextColor="#888"
          />
        </View>

        {/* Category Filters */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.categoriesContainer}
        >
          {categories.map((category) => (
            <TouchableOpacity key={category.id} style={styles.categoryButton}>
              <Text style={styles.categoryText}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Main Category Cards - 2x2 Grid */}
        <View style={styles.categoryCardsContainer}>
          <View style={styles.categoryRow}>
            <TouchableOpacity style={styles.categoryCard}>
              <Text style={styles.categoryCardTitle}>journal.</Text>
              <FeatherIcon />
            </TouchableOpacity>
            <TouchableOpacity style={styles.categoryCard}>
              <Text style={styles.categoryCardTitle}>breathe.</Text>
              <FlowerIcon />
            </TouchableOpacity>
          </View>
          <View style={styles.categoryRow}>
            <TouchableOpacity style={styles.categoryCard}>
              <Text style={styles.categoryCardTitle}>meditate.</Text>
              <MeditationIcon />
            </TouchableOpacity>
            <TouchableOpacity style={styles.categoryCard}>
              <Text style={styles.categoryCardTitle}>quotes &
affirmation.</Text>
              <LightbulbIcon />
            </TouchableOpacity>
          </View>
        </View>

        {/* Based on your day section */}
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>BASED ON YOUR DAY</Text>
          <View style={styles.recommendedContainer}>
            {recommendedActivities.map((activity) => (
              <TouchableOpacity key={activity.id} style={styles.recommendedCard}>
                <View style={styles.recommendedContent}>
                  {activity.icon}
                  <View style={styles.recommendedTextContainer}>
                    <Text style={styles.recommendedTitle}>{activity.title}</Text>
                    <Text style={styles.recommendedSubtitle}>{activity.subtitle}</Text>
                  </View>
                </View>
                <Ionicons name="chevron-forward" size={24} color="#ccc" />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Featured Content */}
        <View style={styles.featuredContainer}>
          {featuredContent.map((item) => (
            <TouchableOpacity key={item.id} style={styles.featuredCard}>
              <View style={styles.featuredIconContainer}>
                {item.icon}
              </View>
              <View style={styles.featuredContent}>
                {item.dateRange && (
                  <Text style={styles.featuredDate}>{item.dateRange}</Text>
                )}
                {item.label && (
                  <Text style={styles.featuredLabel}>{item.label}</Text>
                )}
                <Text style={styles.featuredTitle}>{item.title}</Text>
                {item.description && (
                  <Text style={styles.featuredDescription}>{item.description}</Text>
                )}
                {item.actionText && (
                  <TouchableOpacity style={styles.actionButton}>
                    <Text style={styles.actionButtonText}>{item.actionText}</Text>
                    <Ionicons name="chevron-forward" size={16} color="#fff" />
                  </TouchableOpacity>
                )}
                {!item.actionText && (
                  <Ionicons name="chevron-forward" size={24} color="#000" style={styles.chevronIcon} />
                )}
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Filters Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={filtersModalVisible}
        onRequestClose={() => setFiltersModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setFiltersModalVisible(false)}
              >
                <Ionicons name="close" size={28} color="#000" />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalScrollView}>
              {/* Filters Section */}
              <Text style={styles.sectionHeaderText}>filters.</Text>
              <View style={styles.filtersSection}>
                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('morningQuestions')}
                >
                  <Text style={styles.filterItemText}>morning questions</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.morningQuestions && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('eveningQuestions')}
                >
                  <Text style={styles.filterItemText}>evening questions</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.eveningQuestions && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('photos')}
                >
                  <Text style={styles.filterItemText}>photos</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.photos && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>
              </View>

              {/* Exercises Section */}
              <Text style={styles.sectionHeaderText}>exercises.</Text>
              <View style={styles.filtersSection}>
                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('journal')}
                >
                  <Text style={styles.filterItemText}>journal</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.journal && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('breathing')}
                >
                  <Text style={styles.filterItemText}>breathing</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.breathing && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('meditation')}
                >
                  <Text style={styles.filterItemText}>meditation</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.meditation && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('moodCheckIn')}
                >
                  <Text style={styles.filterItemText}>mood check-in</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.moodCheckIn && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('quote')}
                >
                  <Text style={styles.filterItemText}>quote</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.quote && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('affirmation')}
                >
                  <Text style={styles.filterItemText}>affirmation</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.affirmation && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('readingSession')}
                >
                  <Text style={styles.filterItemText}>reading session</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.readingSession && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.filterItem}
                  onPress={() => toggleFilter('walks')}
                >
                  <Text style={styles.filterItemText}>walks</Text>
                  <View style={[
                    styles.filterToggle, 
                    selectedFilters.walks && styles.filterToggleSelected
                  ]} />
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  menuButton: {
    padding: 5,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#eee",
    borderRadius: 25,
    marginHorizontal: 20,
    marginTop: 5,
    paddingHorizontal: 15,
    height: 50,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: "#333",
  },
  categoriesContainer: {
    marginTop: 20,
    paddingHorizontal: 15,
  },
  categoryButton: {
    backgroundColor: "#fff",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 25,
    marginRight: 10,
  },
  categoryText: {
    fontSize: 14,
    fontWeight: "500",
    color: "#333",
  },
  categoryCardsContainer: {
    marginTop: 20,
    paddingHorizontal: 15,
  },
  categoryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },
  categoryCard: {
    backgroundColor: "#000",
    width: "48%",
    aspectRatio: 1,
    borderRadius: 20,
    padding: 20,
    justifyContent: "space-between",
  },
  categoryCardTitle: {
    color: "#fff",
    fontSize: 24,
    fontWeight: "bold",
  },
  svgContainer: {
    alignSelf: "flex-end",
    marginBottom: 10,
  },
  svgIcon: {
    fontSize: 32,
  },
  sectionContainer: {
    marginTop: 30,
    paddingHorizontal: 15,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "500",
    color: "#999",
    marginBottom: 15,
    letterSpacing: 1,
  },
  recommendedContainer: {
    marginTop: 10,
  },
  recommendedCard: {
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 20,
    marginBottom: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  recommendedContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  recommendedTextContainer: {
    marginLeft: 15,
  },
  recommendedTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  recommendedSubtitle: {
    fontSize: 18,
    color: "#999",
    marginTop: 5,
  },
  featuredContainer: {
    marginTop: 20,
    paddingHorizontal: 15,
    marginBottom: 30,
  },
  featuredCard: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderRadius: 20,
    marginBottom: 15,
    overflow: "hidden",
  },
  featuredIconContainer: {
    width: "30%",
    aspectRatio: 1,
    backgroundColor: "#000",
    justifyContent: "center",
    alignItems: "center",
  },
  featuredContent: {
    flex: 1,
    padding: 15,
    justifyContent: "center",
  },
  featuredDate: {
    fontSize: 14,
    color: "#999",
    marginBottom: 5,
  },
  featuredLabel: {
    fontSize: 14,
    color: "#999",
    marginBottom: 5,
  },
  featuredTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  featuredDescription: {
    fontSize: 14,
    color: "#999",
    lineHeight: 20,
  },
  actionButton: {
    backgroundColor: "#000",
    borderRadius: 25,
    paddingVertical: 10,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    marginTop: 15,
  },
  actionButtonText: {
    color: "#fff",
    fontWeight: "bold",
    marginRight: 5,
  },
  chevronIcon: {
    position: "absolute",
    right: 10,
    top: "50%",
    marginTop: -12,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    flex: 1,
    backgroundColor: '#f7f7f7',
    borderRadius: 20,
    marginTop: 20,
    paddingBottom: 30,
  },
  modalHeader: {
    alignItems: 'flex-end',
    padding: 15,
  },
  closeButton: {
    padding: 10,
  },
  modalScrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  sectionHeaderText: {
    fontSize: 36,
    fontWeight: '700',
    color: '#1c1c1e',
    marginVertical: 20,
  },
  filtersSection: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 30,
  },
  filterItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  filterItemText: {
    fontSize: 20,
    color: '#1c1c1e',
  },
  filterToggle: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  filterToggleSelected: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
});