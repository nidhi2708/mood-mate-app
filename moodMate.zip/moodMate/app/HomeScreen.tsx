import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { StackNavigationProp } from "@react-navigation/stack";

// Define the RootStackParamList for navigation typing
type RootStackParamList = {
  HomeScreen: undefined;
  SettingsStack: undefined;
  MoodMate: { 
    sessionType?: string;
    initialMessage?: string;
  };
  Journey: { noteTitle?: string };
  Trends: undefined;
  Settings: undefined;
  Explore: undefined;
};

type HomeScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  "HomeScreen"
>;

export default function HomeScreen() {
  const navigation = useNavigation<HomeScreenNavigationProp>();
  const [selectedDay, setSelectedDay] = useState(new Date().getDate() - 1); // Default to current date (0-indexed)

  // Get current date info
  const currentDate = new Date();
  const currentHour = currentDate.getHours();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  // Dynamic greeting based on time of day
  let greeting = "good morning.";
  if (currentHour >= 12 && currentHour < 18) {
    greeting = "good afternoon.";
  } else if (currentHour >= 18) {
    greeting = "good evening.";
  }

  // Generate days for the current month
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const daysInMonth = getDaysInMonth(currentYear, currentMonth);

  // Get day name
  const getDayName = (year: number, month: number, day: number) => {
    const date = new Date(year, month, day);
    return date.toLocaleDateString("en-US", { weekday: "short" }).slice(0, 3);
  };

  // Get full day name
  const getFullDayName = (year: number, month: number, day: number) => {
    const date = new Date(year, month, day);
    return date.toLocaleDateString("en-US", { weekday: "long" }).toUpperCase();
  };

  // Generate the days array for the current month
  const monthDays = Array.from({ length: daysInMonth }, (_, i) => {
    const dayNumber = i + 1;
    return {
      shortName: getDayName(currentYear, currentMonth, dayNumber),
      date: dayNumber.toString().padStart(2, "0"),
    };
  });

  // Get the current selected day's full name
  const selectedDayName = getFullDayName(
    currentYear,
    currentMonth,
    selectedDay + 1 // Convert from 0-indexed to actual date
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.topBar}>
          <View style={styles.logoContainer}>
            <Ionicons name="leaf-outline" size={24} color="#999" />
            <Text style={styles.logoText}>0</Text>
          </View>
          <TouchableOpacity
            style={styles.profileButton}
            onPress={() => navigation.navigate("Settings")}
          >
            <Ionicons name="person-circle" size={36} color="#333" />
          </TouchableOpacity>
        </View>

        {/* Greeting */}
        <View style={styles.greetingContainer}>
          <Text style={styles.greeting}>{greeting}</Text>
        </View>

        {/* Date Slider */}
        <View style={styles.dateSliderContainer}>
          <TouchableOpacity
            style={styles.sliderArrow}
            onPress={() =>
              setSelectedDay((prev) => (prev > 0 ? prev - 1 : prev))
            }
          >
            <Ionicons
              name="chevron-back"
              size={24}
              color={selectedDay > 0 ? "#333" : "#CCC"}
            />
          </TouchableOpacity>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.dateSlider}
          >
            {monthDays.map((day, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.dayItem,
                  selectedDay === index && styles.selectedDayItem,
                ]}
                onPress={() => setSelectedDay(index)}
              >
                <Text
                  style={[
                    styles.dayText,
                    selectedDay === index && styles.selectedDayText,
                  ]}
                >
                  {day.shortName}
                </Text>
                <Text
                  style={[
                    styles.dateText,
                    selectedDay === index && styles.selectedDateText,
                  ]}
                >
                  {day.date}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity
            style={styles.sliderArrow}
            onPress={() =>
              setSelectedDay((prev) =>
                prev < monthDays.length - 1 ? prev + 1 : prev
              )
            }
          >
            <Ionicons
              name="chevron-forward"
              size={24}
              color={selectedDay < monthDays.length - 1 ? "#333" : "#CCC"}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.divider} />

        {/* Day Section */}
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>{selectedDayName}</Text>

          <View style={styles.cardsRow}>
            {/* Morning Card */}
            <TouchableOpacity
              style={[styles.card, styles.darkCard]}
              onPress={() => navigation.navigate("MoodMate", { 
                sessionType: "morning",
                initialMessage: "Good morning! I'd like to prepare for my day."
              })}
            >
              <View style={styles.cardContent}>
                <View>
                  <Text style={styles.cardTitle}>
                    Let's start{"\n"}your day
                  </Text>
                  <Text style={styles.cardSubtitle}>
                    with morning{"\n"}preparation
                  </Text>
                </View>
                <View style={styles.iconCircle}>
                  <View style={styles.whiteCircle} />
                </View>
              </View>
            </TouchableOpacity>

            {/* Evening Card */}
            <TouchableOpacity
              style={[styles.card, styles.lightCard]}
              onPress={() => navigation.navigate("MoodMate", {
                sessionType: "evening",
                initialMessage: "I'd like to reflect on my day today."
              })}
            >
              <View style={styles.cardContent}>
                <View>
                  <Text style={[styles.cardTitle, { color: "#333" }]}>
                    Evening{"\n"}Reflection
                  </Text>
                  <Text style={[styles.cardSubtitle, { color: "#777" }]}>
                    Sum up your day
                  </Text>
                </View>
                <View
                  style={[
                    styles.iconCircle,
                    { backgroundColor: "transparent" },
                  ]}
                >
                  <View style={styles.moonShape} />
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* GET INSPIRED Section */}
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>GET INSPIRED</Text>
          
          <View style={{height: 380, marginTop: 10}}>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              pagingEnabled
              decelerationRate="fast"
              snapToInterval={280}
            >
              {/* Intro Card */}
              <View style={{
                width: 280,
                height: 380,
                backgroundColor: '#FFF',
                borderRadius: 25,
                marginRight: 16,
                padding: 20,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 2,
                justifyContent: 'center',
              }}>
                <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                  <Text style={{
                    fontSize: 32,
                    fontWeight: '700',
                    color: '#1E1E1E',
                    textAlign: 'center',
                    marginBottom: 40,
                  }}>
                    Looking for more{'\n'}Inspiration?
                  </Text>
                  <TouchableOpacity 
                    style={{
                      backgroundColor: '#1E1E1E',
                      paddingHorizontal: 30,
                      paddingVertical: 15,
                      borderRadius: 30,
                    }}
                    onPress={() => navigation.navigate("Explore")}
                  >
                    <Text style={{color: '#FFF', fontSize: 18, fontWeight: '600'}}>Get Inspired</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Quote Card */}
              <View style={{
                width: 280,
                height: 380,
                backgroundColor: '#FFF',
                borderRadius: 25,
                marginRight: 16,
                padding: 20,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 2,
                justifyContent: 'center',
              }}>
                <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                  <Text style={{fontSize: 80, color: '#1E1E1E'}}>❞</Text>
                  <Text style={{
                    fontSize: 28,
                    fontWeight: '700',
                    color: '#1E1E1E',
                    textAlign: 'center',
                    marginBottom: 20,
                  }}>
                    The antidote for fifty enemies is one friend.
                  </Text>
                  <Text style={{fontSize: 20, color: '#999', marginBottom: 40}}>Aristotle</Text>
                  <TouchableOpacity 
                    style={{
                      borderColor: '#1E1E1E',
                      borderWidth: 1,
                      paddingHorizontal: 40,
                      paddingVertical: 12,
                      borderRadius: 30,
                    }}
                    onPress={() => navigation.navigate("Journey", { 
                      noteTitle: "The antidote for fifty enemies is one friend." 
                    })}
                  >
                    <Text style={{color: '#1E1E1E', fontSize: 18}}>Reflect</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Daily Affirmation */}
              <View style={{
                width: 280,
                height: 380,
                backgroundColor: '#FFF',
                borderRadius: 25,
                marginRight: 16,
                padding: 20,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 2,
                justifyContent: 'center',
              }}>
                <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                  <Ionicons name="sunny" size={40} color="#000" style={{marginBottom: 10}} />
                  <Text style={{
                    fontSize: 18,
                    color: '#999',
                    marginBottom: 20,
                  }}>Daily Affirmation</Text>
                  <Text style={{
                    fontSize: 32,
                    fontWeight: '700',
                    color: '#1E1E1E',
                    textAlign: 'center',
                    marginBottom: 40,
                  }}>
                    I believe that my time is valuable.
                  </Text>
                  <TouchableOpacity 
                    style={{
                      borderColor: '#1E1E1E',
                      borderWidth: 1,
                      paddingHorizontal: 40,
                      paddingVertical: 12,
                      borderRadius: 30,
                    }}
                    onPress={() => navigation.navigate("Journey", { 
                      noteTitle: "I believe that my time is valuable." 
                    })}
                  >
                    <Text style={{color: '#1E1E1E', fontSize: 18}}>Reflect</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Question Prompt */}
              <View style={{
                width: 280,
                height: 380,
                backgroundColor: '#FFF',
                borderRadius: 25,
                marginRight: 16,
                padding: 20,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 2,
                justifyContent: 'center',
              }}>
                <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                  <Ionicons name="bulb" size={40} color="#000" style={{marginBottom: 20}} />
                  <Text style={{
                    fontSize: 32,
                    fontWeight: '700',
                    color: '#1E1E1E',
                    textAlign: 'center',
                    marginBottom: 40,
                  }}>
                    Do you think you might be a source of gratitude for someone else?
                  </Text>
                  <TouchableOpacity 
                    style={{
                      borderColor: '#1E1E1E',
                      borderWidth: 1,
                      paddingHorizontal: 40,
                      paddingVertical: 12,
                      borderRadius: 30,
                    }}
                    onPress={() => navigation.navigate("Journey", { 
                      noteTitle: "Do you think you might be a source of gratitude for someone else?" 
                    })}
                  >
                    <Text style={{color: '#1E1E1E', fontSize: 18}}>Reflect</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F5F5",
    padding: 16,
  },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 40,
    marginTop: 10,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  logoText: {
    fontSize: 20,
    color: "#999",
    marginLeft: 6,
  },
  profileButton: {
    padding: 4,
  },
  greetingContainer: {
    alignItems: "center",
    marginBottom: 40,
  },
  greeting: {
    fontSize: 42,
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
  },
  dateSliderContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
    paddingHorizontal: 5,
  },
  sliderArrow: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  dateSlider: {
    paddingHorizontal: 10,
    alignItems: "center",
  },
  dayItem: {
    alignItems: "center",
    width: 40,
  },
  selectedDayItem: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  dayText: {
    fontSize: 16,
    color: "#999",
    marginBottom: 4,
  },
  selectedDayText: {
    color: "#333",
  },
  dateText: {
    fontSize: 22,
    color: "#999",
    fontWeight: "500",
  },
  selectedDateText: {
    color: "#333",
    fontWeight: "bold",
  },
  divider: {
    height: 1,
    backgroundColor: "#EEE",
    marginVertical: 20,
  },
  sectionContainer: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 14,
    color: "#999",
    letterSpacing: 1.5,
    marginBottom: 16,
    textAlign: "center",
  },
  cardsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  card: {
    width: "48%",
    height: 200,
    borderRadius: 20,
    padding: 20,
    justifyContent: "flex-end",
  },
  darkCard: {
    backgroundColor: "#1E1E1E",
  },
  lightCard: {
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: "#EEE",
  },
  cardContent: {
    flex: 1,
    justifyContent: "space-between",
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: "600",
    color: "white",
    marginBottom: 8,
    lineHeight: 28,
  },
  cardSubtitle: {
    fontSize: 14,
    color: "#999",
    lineHeight: 20,
  },
  iconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "flex-start",
    marginTop: 20,
  },
  whiteCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: "#FFF",
  },
  moonShape: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: "transparent",
    borderWidth: 2,
    borderColor: "#333",
    borderTopWidth: 0,
    borderRightWidth: 0,
    transform: [{ rotate: "60deg" }],
  },
}); 