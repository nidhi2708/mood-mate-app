# MoodMate Project Documentation

## Overview

This directory contains documentation for the MoodMate application, including architecture diagrams, data flow visualizations, and other technical documentation.

## Contents

- `flow-diagram.md` - Comprehensive flow diagrams showing the application architecture, user journeys, data models, and key processes

## How to View the Diagrams

The flow diagrams are created using Mermaid, a markdown-based diagramming tool. To view these diagrams:

1. **GitHub**: If you're viewing this on GitHub, the diagrams should render automatically in the markdown files.

2. **VS Code**: Install the "Markdown Preview Mermaid Support" extension to view the diagrams directly in VS Code's markdown preview.

3. **Mermaid Live Editor**: Copy the diagram code and paste it into the [Mermaid Live Editor](https://mermaid.live/) for an interactive view.

4. **Export as Images**: You can export the diagrams as PNG or SVG files from the Mermaid Live Editor for inclusion in other documents.

## Diagram Types

The flow-diagram.md file includes several types of diagrams:

1. **Application Architecture** - Shows the main components and their relationships
2. **User Journey Flow** - Illustrates the sequence of interactions between the user and system components
3. **Data Model** - Displays the database schema and relationships between entities
4. **Authentication Flow** - Details the login and session management process
5. **MoodMate AI Conversation Flow** - Shows how the AI assistant processes and responds to user messages

## Updating Diagrams

As the application evolves, please keep these diagrams updated to reflect the current architecture. Mermaid syntax is relatively simple to learn and modify.