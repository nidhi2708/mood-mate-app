# MoodMate Application Flow Diagram

This document provides a visual representation of the MoodMate application architecture, data flow, and user journey.

## Application Architecture

```mermaid
flowchart TD
    %% Main Components
    User([User]) --> App[MoodMate App]
    
    %% Main Screens
    App --> HomeScreen[Home Screen]
    App --> MoodMateScreen[MoodMate AI Assistant]
    App --> ChatScreen[Chat History]
    App --> TrendsScreen[Trends]
    App --> SettingsScreen[Settings]
    
    %% Backend Services
    SupabaseDB[(Supabase Database)] <--> SupabaseService[Supabase Service]
    ClaudeAPI[(Claude AI API)] <--> ClaudeService[Claude Service]
    
    %% Data Flow
    SupabaseService <--> App
    ClaudeService <--> App
    
    %% Detailed Connections
    HomeScreen --> MoodMateScreen
    ChatScreen --> NewChat[New Chat]
    ChatScreen --> ChatDetail[Chat Detail]
    SettingsScreen --> AccountSettings[Account Settings]
    
    %% Database Tables
    SupabaseDB --> Conversations[(Conversations Table)]
    SupabaseDB --> Messages[(Messages Table)]
    SupabaseDB --> Auth[(Auth Users)]
    
    %% Styling
    classDef screen fill:#f9f9f9,stroke:#333,stroke-width:1px
    classDef service fill:#e1f5fe,stroke:#0288d1,stroke-width:1px
    classDef database fill:#e8f5e9,stroke:#388e3c,stroke-width:1px
    classDef api fill:#fff8e1,stroke:#ffa000,stroke-width:1px
    
    class HomeScreen,MoodMateScreen,ChatScreen,TrendsScreen,SettingsScreen,NewChat,ChatDetail,AccountSettings screen
    class SupabaseService,ClaudeService service
    class SupabaseDB,Conversations,Messages,Auth database
    class ClaudeAPI api
```

## User Journey Flow

```mermaid
sequenceDiagram
    actor User
    participant Home as Home Screen
    participant MoodMate as MoodMate AI
    participant Chat as Chat History
    participant Supabase as Supabase DB
    participant Claude as Claude API
    
    User->>Home: Opens app
    User->>MoodMate: Starts conversation
    MoodMate->>Claude: Sends user message
    Claude->>MoodMate: Returns AI response
    MoodMate->>User: Displays AI response
    
    User->>Chat: Views chat history
    Chat->>Supabase: Fetches conversations
    Supabase->>Chat: Returns conversation list
    User->>Chat: Selects conversation
    Chat->>Supabase: Fetches messages
    Supabase->>Chat: Returns message history
    Chat->>User: Displays conversation
    
    User->>Chat: Creates new chat
    Chat->>Supabase: Creates conversation record
    Chat->>Claude: Sends initial message
    Claude->>Chat: Returns AI response
    Chat->>Supabase: Stores messages
    Chat->>User: Displays conversation
```

## Data Model

```mermaid
erDiagram
    USERS ||--o{ CONVERSATIONS : creates
    CONVERSATIONS ||--o{ MESSAGES : contains
    
    USERS {
        uuid id PK
        string email
        string encrypted_password
        timestamp created_at
        timestamp updated_at
    }
    
    CONVERSATIONS {
        uuid id PK
        uuid user_id FK
        string title
        timestamp created_at
        timestamp updated_at
    }
    
    MESSAGES {
        uuid id PK
        uuid conversation_id FK
        string role
        string content
        timestamp created_at
    }
```

## Authentication Flow

```mermaid
sequenceDiagram
    actor User
    participant App as MoodMate App
    participant Auth as Supabase Auth
    participant DB as Supabase Database
    
    User->>App: Opens app
    App->>Auth: Check session
    
    alt Logged in
        Auth->>App: Return user session
        App->>DB: Fetch user data
        DB->>App: Return user data
        App->>User: Show home screen
    else Not logged in
        Auth->>App: No active session
        App->>User: Show login screen
        User->>App: Enter credentials
        App->>Auth: Sign in request
        Auth->>App: Authentication result
        
        alt Authentication successful
            App->>DB: Fetch user data
            DB->>App: Return user data
            App->>User: Show home screen
        else Authentication failed
            App->>User: Show error message
        end
    end
```

## MoodMate AI Conversation Flow

```mermaid
sequenceDiagram
    actor User
    participant UI as MoodMate UI
    participant Claude as Claude Service
    participant API as Claude API
    participant DB as Supabase DB
    
    User->>UI: Enters message
    UI->>Claude: Sends user message
    
    alt API Key Set
        Claude->>API: Formats request with system instructions
        API->>Claude: Returns AI response
        Claude->>UI: Formats and returns response
        UI->>User: Displays AI response
        UI->>DB: Stores conversation (optional)
    else No API Key
        Claude->>UI: Returns error
        UI->>User: Prompts for API key
        User->>UI: Provides API key
        UI->>Claude: Sets API key
        Claude->>API: Formats request with system instructions
        API->>Claude: Returns AI response
        Claude->>UI: Formats and returns response
        UI->>User: Displays AI response
    end
```